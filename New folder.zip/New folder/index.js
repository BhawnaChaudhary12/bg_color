document.getElementById("colorButton").addEventListener("click", function() {
    const colors = [];
    const numColors = 6;

    for (let i = 0; i < numColors; i++) {
        const color = '#' + Math.floor(Math.random() * 16777215).toString(16).padStart(6, '0');
        colors.push(color);
    }

    const gradient = `linear-gradient(to right, ${colors.join(', ')})`;
    document.body.style.background =  gradient;

    const colorNamesDiv = document.getElementById('colorNames');
    colorNamesDiv.innerHTML = `Colors: ${colors.join(', ')}`;
});